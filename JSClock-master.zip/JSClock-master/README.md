## JSClock
Garmin Watch Face for Vivoactive HR

A digital version of Garmin watch face. This clockface show clock, date, week, kcal, step, your goals, floor (only Vivoactive HR), connection to phone, battery status and message.

You can change colour, change activity field and a lot more in app settings.

<A HREF="https://apps.garmin.com/en-US/apps/26f04fcd-61e4-43df-997b-8df2dc19c9c9">https://apps.garmin.com/en-US/apps/26f04fcd-61e4-43df-997b-8df2dc19c9c9</A>

![alt tag](https://github.com/jensws80/JSClock/blob/master/jsclock_cover_400400.jpg?raw=true(http://jensws.com/images/jsclock_cover_400400.jpg))


![alt tag](https://github.com/jensws80/JSClock/blob/master/JSClock.png?raw=true(http://jensws.com/images/JSClock.png))
![alt tag](https://github.com/jensws80/JSClock/blob/master/JSClock2.png?raw=true(http://jensws.com/images/JSClock2.png))
![alt tag](https://github.com/jensws80/JSClock/blob/master/JSClock3.png?raw=true(http://jensws.com/images/JSClock3.png))

## Version

1.0 First version

1.1 Add support for more clock. All Rectangle and semi round are supported.

1.2 Add settings meny, You can now change color and change the two activity field between kcal, distance, step and floor (floor only Vivoactive HR). 

1.3 Add week number (iso), more colour for you too choose between, Possible to show goals, set color on/off, One more activity field for you too activate.

1.4 Graphics change and distance show in 0.0

1.5 Add probability in settings for alarm colour and level when low battery activates.

1.6 Add all 16 colour supported by all clock and graphics change.

1.7 Bug Fix

1.8 Removed graphics arc, possible to choose miles, heart rate and sleep mode

1.9 Bug Fix

2.0 Add more color option for Vivoactive HR and update code to support Connect IQ SDK 3.0

## License
This project is licensed under the terms of the GNU V.3 license.
